<?php $__env->startSection('content'); ?>

<div class="rel_content">
	<div class="notice">
	  <p>This is relationships table.They used for data integrity. In the example below relationship "one to many". For example: one seller may have a lot of goods. In this example I used Eloquent ORM. Check please.</p>
	</div>

	<p class="instruction">Select please seller</p>

	<div class="button_select">
		<?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<a href="<?php echo e(route('sellers.show', ['id' => $seller->id])); ?>" class=""><?php echo e($seller->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>	
	</div>		
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>