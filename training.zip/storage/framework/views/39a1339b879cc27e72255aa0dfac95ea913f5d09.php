<?php $__env->startSection('content'); ?>

<div class="val_content">

	<div class="notice">
	  <p>This is validation. Validation is needed because invalid data can break the program execution. This is an important aspect in any web application.</p>
	</div>

	<?php if(session()->has('message')): ?>
		<div class="success_message">
			<p><?php echo e(session('message')); ?></p>
		</div>
	<?php endif; ?>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<div class="error_message">
			<p><?php echo e($error); ?></p>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

	<div class="form valid">	
		<form method="POST" action="<?php echo e(action('WorkerController@store')); ?>">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="text" name="name" placeholder="name">
			<input type="text" name="age" placeholder="age">
			<button type="submit">Add</button>
		</form>
	</div>
</div>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>