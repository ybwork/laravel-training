<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="notice">
		  <p>Pagination is used in web applications for break  large data set into pages, and includes a navigation block to navigate to other pages. On each page will be 2 articles.</p>
	</div>
	<div class="articles_wrap">
		    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		        <h3><?php echo e($article->title); ?></h3>
		        <p><?php echo e($article->text); ?></p>
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		<?php echo e($articles->render()); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>