<?php $__env->startSection('content'); ?>


<div class="form edit">
	<div class="error_message">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<p><?php echo e($error); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
	<form action="<?php echo e(action('PlayerController@update', ['id' => $player->id])); ?>" method="POST">
		<?php echo e(method_field('PUT')); ?>

		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<input type="text" value="<?php echo e($player->name); ?>" name="name">
		<button type="submit">Update</button>
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>