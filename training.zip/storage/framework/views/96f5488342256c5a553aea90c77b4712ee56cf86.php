<?php $__env->startSection('content'); ?>

<div class="notice">
  <p>Confidentiality and safety. All of this can encryption. Enter any password please and click on button encryption.</p>
</div>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
<div class="error_message">
	<p><?php echo e($error); ?></p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<div>

	<div class="form">
		<form action="<?php echo e(action('PasswordController@store')); ?>" method="POST">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="text" name="password">
			<button type="submit">Encryprion</button>
		</form>
	</div>

	<table class="table">
	    <thead>
	      <tr>
	        <th class="title_table">id</th>
	        <th class="title_table">encryption password</th>
	      </tr>
	    </thead>
		<?php $__currentLoopData = $passwords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $password): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		    <tbody>
		      <tr>
		        <td class="table_content"><?php echo e($password->id); ?></td>
		        <td class="table_content"><?php echo e($password->password); ?></td>
		      </tr>
		    </tbody>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>