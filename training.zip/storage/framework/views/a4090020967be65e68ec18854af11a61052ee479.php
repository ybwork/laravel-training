<?php $__env->startSection('content'); ?>

<div class="rel_content">
	
	<?php $__currentLoopData = $seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<p class="seller"><span><?php echo e($seller->name); ?></span> have this is products:</p>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

	<div class="products">	
		<ul>
			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li><?php echo e($product->name); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</ul>
	</div>		

	<p class="instruction">Select other seller</p>

	<div class="button_select">

		<?php $__currentLoopData = $other_sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other_sellers): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			<a href="<?php echo e(route('sellers.show', ['id' => $other_sellers->id])); ?>"><?php echo e($other_sellers->name); ?></a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>