<?php $__env->startSection('content'); ?>

	<div class="notice">
	  <p>This search shows the type of relationships between tables "one-to-many". In this example I use laravel Query Builder.</p>
	</div>

	<div class="form">	
		<form action="<?php echo e(route('places.index')); ?>" method="GET" role="form">
				<select name="category">
					<option value="">All categories</option>
					<option value="1">Entertaiment</option>
					<option value="2">Art</option>
				</select>
				<select name="direction">
					<option value="">All directions</option>
					<option value="1">Bar</option>
					<option value="2">Club</option>
					<option value="3">Teater</option>
					<option value="4">Museum</option>
				</select>
			<button type="submit">Search</button>
		</form>	
	</div>

	<table class="table">
	    <thead>
	      <tr>
	        <th class="title_table">id</th>
	        <th class="title_table">place</th>
	      </tr>
	    </thead>
		<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		    <tbody>
		      <tr>
		        <td class="table_content"><?php echo e($result->id); ?></td>
		        <td class="table_content"><?php echo e($result->name); ?></td>
		      </tr>
		    </tbody>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>