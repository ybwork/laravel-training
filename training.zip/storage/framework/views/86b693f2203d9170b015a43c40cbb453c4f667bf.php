<?php $__env->startSection('content'); ?>

	<div class="notice">
	  <p>This is REST. REST are the architectural style of interaction of components applications in the network. It is a single standard. To work with the data it uses the methods: GET, POST, PUT, DELETE.</p>
	</div>

	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<div class="error_message">
		<p><?php echo e($error); ?></p>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

	<div class="form">
		<form action="<?php echo e(action('PlayerController@store')); ?>" method="POST">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="text" placeholder="Write your name" name="name">
			<button type="submit">Create</button>
		</form>
	</div>

	<table class="table">
	    <thead>
	      <tr>
	        <th class="title_table">id</th>
	        <th class="title_table">phrase</th>
	        <th class="title_table">action</th>
	      </tr>
	    </thead>
		<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	    <tbody>
	      <tr>
	        <td class="table_content"><?php echo e($player->id); ?></td>
	        <td class="table_content"><?php echo e($player->name); ?></td>
	        <td class="table_content">

				<a href="<?php echo e(route('player.edit', ['id' => $player->id])); ?>" type="button" class="action_link fa fa-pencil"></a>

				<form class="action_link" action="<?php echo e(action('PlayerController@destroy', ['id' => $player->id])); ?>" method="POST">
					<?php echo e(method_field('DELETE')); ?>

					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<button type="submit" class="fa fa-trash-o"></button>
				</form>
	        </td>
	      </tr>
	    </tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>