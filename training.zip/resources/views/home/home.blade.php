@extends('layouts.app')

@section('content')
	<p class="home"><span class="word_lara">Laravel</span><span class="word_tasks">Training</span></p>
@stop